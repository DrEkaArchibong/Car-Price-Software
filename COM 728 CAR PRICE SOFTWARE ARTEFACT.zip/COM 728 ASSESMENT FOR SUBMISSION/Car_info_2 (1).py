#!/usr/bin/env python
# coding: utf-8

# In[ ]:

import pandas as pd
def loading():
    
    file_path = input('Please enter the file path:' )
    try:
        with open(file_path) as file:
            
            df = pd.read_csv(file)
            df.head()
            print('Operation completed!')
            return df.head()

    except IOError:
        print('invalid directory')
        


# In[ ]:


def retrieve(df):
    print("To retrieve record for an individual car by ID: 1. \n To retrieve all cars for a specified cylinder number:2. \n To retrieve a specific number of columns, 2 to 5, related to an individual car by ID: 3. \n Retrieve all cars in a specified car body: 4")
    print("----------------------------------------------------------------------")
    action = int(input("enter the actions you want to perform: "))
    if action ==1:
        entry = int(input("enter car ID: "))
        return df.loc[entry]
        
    elif action ==2:
        cylinder_number = int(input("enter cylinder number: "))
        return df.loc[df.cylindernumber== cylinder_number]
        
    elif action ==3:
        car_ID = int(input("enter car ID, where car ID is your entry +1: "))
        entries = int(input("enter number of features you want to access: "))
        for columns in range(entries):
            columns = input("enter the features: ")
            print(df.loc[car_ID, [columns]])
        
    elif action==4:
        car_body = input("Please specify the car body: ")
        return df.loc[df.carbody== car_body]


# In[ ]:


def sorting(df):
    action = input("Enter Yes or No to sort the dataset Alphabetically: ")
    
#to ignore case sensitivity, we use the below line of code
    action = action.lower()
    if action == "yes":
        df['CarName'] = df["CarName"].replace({"Nissan versa": "nissan versa"}, inplace = False)
        df = df.sort_values('CarName')
        return df
    else:
        print("invalid command")


# In[ ]:


def Top5(df):
    carbody = input('enter car body to retrieve top 5 car sales: ')
    top_5 = df.loc[df['carbody'] == carbody]
    top_5 = top_5.sort_values(by = 'price', ascending = False).head()
    ans = top_5.iloc[:, 4::15]
    return ans


# In[ ]:


def summary_of_sales(df):
    carbody = input("Enter car body to retrieve summary of sales: ")
    Total_carPrice = sum(df.loc[df['carbody'] == carbody].price)
    return f"Total car price for {carbody} is: {Total_carPrice}"


# In[ ]:



import matplotlib.pyplot as plt

df = pd.read_csv("CarPrice.csv")
def visualisation(df):
    
    print('To display the number of cars per fuel system in a bar chart, enter 1')
    print('To Display the horsepower of the top 5 car sale by price (the cheapest) using a subplot, enter 2')

    action = int(input('action: '))
    if action == 1:
        df['fuelsystem'].value_counts().plot(kind = "bar");
    elif action ==2:
       
        fig, ax = plt.subplots(figsize=(15, 12))
        df2 = df.sort_values(by ='price', ascending= True).head()
        # get CarNmae from the sorted dataframe df2 and add to list
        CarName = df2['CarName'].to_list()

        #Get the horsepower from the sliced dataframe df2 and add to list
        horsepower = df2['horsepower'].to_list()

        #name the figure
        fig.suptitle("Horsepower of Top 5 Cheapest Cars")

        # loop through the length of car names list in dataframe df2 keeping track of index
        for i in range(len(df2['CarName'])):
            # add a new subplot iteratively
            ax = plt.subplot(1, 5, i + 1)
    
            ax.bar(CarName[i],horsepower[i])

            # chart formatting 
            ax.set_ylim(40,75) # set y-xais limit value
    else:
        print('You have entered an invalid command')

visualisation(df)
# In[ ]:


# Optional Functioms
def optional(df):
    print("To group the dataset by carbody, enter 1.\nTo know the total number of cars sold, per carbody, enter 2. \nTo see the carbody preference in a piechart, enter 3")
    action_2 = int(input('action_2: ' ))
    if action_2 == 1:
        group = df.groupby(['carbody'])
        car_body = input('enter car body')
        group2 = group.get_group(car_body)
        return group2
    elif action_2 == 2:
        carbodysum = df['carbody'].value_counts()
        return carbodysum
        
    elif action_2 == 3:
    
        fig = plt.figure(figsize = (9,7))
        percentage = [47,34,10,5,4]
        carbody = ['sedan', 'hatchback', 'wagon', 'hardtop', 'convertible']
        plt.pie(percentage,labels=carbody, autopct='%1.1f%%') 
        plt.title("carbody preference")
        plt.legend()
        plt.show()     
      





