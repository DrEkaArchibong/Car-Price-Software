#!/usr/bin/env python
# coding: utf-8

# In[8]:


LINE_WIDTH = 75

def started():
    output = f"Operation started:..."
    dashes = "-" * LINE_WIDTH
    print(f"{dashes}\n{output}\n")


# In[12]:


def menu():
    print('Welcome to my CarPrice Software')
    print('**************************************************************************')
    print('please be aware that the system works with index, for instance, if you need car ID 5, enter 4 ')
    print('                                                                                           ')
    print('Entry 1: To process the loaded data i.e answer all questions in part B, enter 1')
    print('Entry 2: To sort car names alphabetically, enter 2 ')
    print('Entry 3: To retrieve summary of sales (total car price) per car body, enter 3')
    print('Entry 4: To retrieve the top 5 car sale by price(the most expensive) and by car body, enter 4')
    print('Entry 5: To perform visualisation, enter 5')
    print('Entry 6: To perform optional queries, enter 6')
    print('Entry 0: To end the program')
    print('*******************************************************************************')
    action = int(input('What would you like to do? '))
    print(f'You have chosen entry {action}')
    print('-------------------------------------------------------------------------')
    return action



